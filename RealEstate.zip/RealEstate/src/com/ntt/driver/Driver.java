package com.ntt.driver;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.ntt.dao.UserDAO;
import com.ntt.dao.BookedinfoDAO;
import com.ntt.dao.BuyinfoDAO;
import com.ntt.dao.DAOException;
import com.ntt.dao.EloginDAO;
import com.ntt.dao.FhistoryDAO;
import com.ntt.dao.MloginDAO;
import com.ntt.dao.SiteDAO;
import com.ntt.dbcon.DBConnectionException;
import com.ntt.dbfw.DBFWException;
import com.ntt.domain.Bookedinfo;
import com.ntt.domain.Buyinfo;
import com.ntt.domain.Elogin;
import com.ntt.domain.Mlogin;
import com.ntt.domain.Site;
import com.ntt.domain.User;

public class Driver
{
	public static void main(String arg[])throws DBConnectionException
	{
		List slist=null;
		int ch=0, opt = 0;
		int status=0;
		
		Scanner sc=new Scanner(System.in);
		do{
			System.out.println("------MENU-------");					//Menu
			System.out.println("1. Register");
			System.out.println("2. Login");
			System.out.println("Enter any other key to exit");
			System.out.println("------------------");
			System.out.println("Enter your choice.....");
			ch=sc.nextInt();
		    
			switch(ch)
			{
			case 1:
				//Taking input from user to insert
				int result=0;											// Store the result of insert query
				System.out.println("enter your name: ");
				String name=sc.next();
				System.out.println("Enter your email: ");
				String email=sc.next();
				System.out.println("Enter your password: ");
				String pass=sc.next();
				System.out.println("Enter your contact number: ");
				String contactno=sc.next();
				System.out.println("Enter your Role (B - Buyer, S - Seller, A - Admin): ");
				String role=sc.next();
				
				User u = new User(name, email, pass, contactno, role);				//Object initialization using CLASS User
				result=UserDAO.insertUser(u);									//Calling insertUser function
					
				
				if(result!=0)
				{
					System.out.println("User inserted successfully");
				}
				else
				{
					System.out.println("Failed to insert");
				}
				
				break;
				
			case 2:
			{
				try {
					String urole = null;
					List result1 = null;
					System.out.println("Choose the method to Login:");
					System.out.println("1. Email");
					System.out.println("2. Contact number");
					opt=sc.nextInt();
					if(opt == 1) {												//Email Login
						System.out.println("Enter you email: ");
						String email1 = sc.next(); 
						System.out.println("Enter your password: ");
						String pass1 = sc.next(); 
						
						Elogin el = new Elogin(email1, pass1);
						result1 = EloginDAO.eloginSelect(el);
						if(!(result1.isEmpty()))
						{
						System.out.println("Login successfull...");
						System.out.println("---------------- User Role ----------------------");
						for(Iterator it=result1.iterator();it.hasNext();) {
							urole = (String) it.next();										// extract user role
							System.out.println(urole);										// print user role
						}
						}
						else
						{
							System.out.println("Invalid Login details");
							break;
						}
					}
					else if(opt == 2) {											// Mobile number login
						System.out.println("Enter you Contact number: ");
						String contactno1 = sc.next(); 
						System.out.println("Enter your password: ");
						String pass1 = sc.next(); 
						
						Mlogin el = new Mlogin(contactno1, pass1);
						result1 = MloginDAO.mloginSelect(el);
						if(!(result1.isEmpty()))
						{
						System.out.println("Login successfull...");
						System.out.println("---------------- User Role ----------------------");
						for(Iterator it=result1.iterator();it.hasNext();) {
							urole = (String) it.next();										// extract user role
							System.out.println(urole);										// print user role
						}
						}
					 }
					else
						{
							System.out.println("Invalid Login details");
							break;
						}
					
					if(urole.contains("B") == true) {											//Buyer Options -------------
						int cont = 1, opt1 = 0;
						do {
						System.out.println("Welcome Buyer! Select any of the below");
						System.out.println("1. Display available real estate");
						System.out.println("2. click to buy (Info needed - Your name, sitename, book date) ");
						System.out.println("3. To check already bought real estates");
						System.out.println("Any other key to exit");
						opt1=sc.nextInt();
						
						switch(opt1) {
						case 1:
							slist = SiteDAO.getSites();
							if(!(slist.isEmpty()))
							{
							System.out.println("---------------- Site List ----------------------");
							for(Iterator it=slist.iterator();it.hasNext();) {
								System.out.println(it.next());
					 	    }
							}
							else
							{
								System.out.println(" No information available");
							}
							break;
						case 2:
							System.out.println("Enter you Name: ");
							String bname = sc.next(); 
							System.out.println("Enter site name: ");
							String sitename = sc.next();
							System.out.println("Enter the date in YYYY-MM-DD: ");
							String date = sc.next();
							String payment = "Paid";
							Buyinfo b = new Buyinfo(bname, sitename, date, payment);
							result=BuyinfoDAO.insertBuyinfo(b);
								
							
							if(result!=0)
							{
								System.out.println("Buy info inserted successfully");
							}
							else
							{
								System.out.println("Failed to insert");
							}
							
							break;
							
						case 3:
							String bbname = "";
							System.out.println("Enter Buyer name: ");
							bbname = sc.next();
							slist = BuyinfoDAO.getBuyinfo(bbname);
							if(!(slist.isEmpty()))
							{
							System.out.println("---------------- Buy info List ----------------------");
							for(Iterator it=slist.iterator();it.hasNext();) {
								System.out.println(it.next());
					 	    }
							}
							
							break;
					    
						default:
							break;
						}
						
						System.out.println("Press 1 to continue... Any other key to logout");
						cont=sc.nextInt();
						}while(cont == 1);
					}
					
					
					  else if(urole.contains("S") == true) {										//Seller options--------------
						  
						  int cont = 1, opt1 = 0;
							do {
							System.out.println("Welcome Seller! Select any of the below");
							System.out.println("1. Post site for selling/Rent ");
							System.out.println("2. To check buyer details of already posted sites ");
							System.out.println("3. Finalize the deal ");
							System.out.println("Any other key to exit");
							opt1=sc.nextInt();
							
							switch(opt1) {
							case 1:
								
								System.out.println("Enter your Sitename: ");
								String sitename = sc.next(); 
								System.out.println("Enter location: ");
								String loc = sc.next();
								System.out.println("Enter real estate property type (Plot, Home, Apartment): ");
								String proptype = sc.next();
								System.out.println("Enter Amount: ");
								String amount = sc.next();
								System.out.println("Enter selling type (Buy/Rent): ");
								String selltype = sc.next();
								System.out.println("Enter seller name: ");
								String sellername = sc.next();
								Site s1 = new Site(sitename, loc, proptype, amount, selltype, sellername);
								result=SiteDAO.insertSite(s1);
									
								
								if(result!=0)
								{
									System.out.println("Site information inserted successfully");
								}
								else
								{
									System.out.println("Failed to insert");
								}
								
								break;
								
								
								
							case 2:
								System.out.println("Enter the seller name: ");
								String sname=sc.next();
								slist = BookedinfoDAO.getBookedinfo(sname);
								if(!(slist.isEmpty()))
								{
								System.out.println("----------------Booked Site List ----------------------");
								for(Iterator it=slist.iterator();it.hasNext();) {
									System.out.println(it.next());
						 	    }
								}
								else
								{
									System.out.println(" No booking information available");
								}
								break;
								
							case 3:
								System.out.println("Enter the site name: ");
								String site_name=sc.next();
								System.out.println("Enter the seller name: ");
								String selname=sc.next();
								System.out.println("Enter the Buyer name: ");
								String buyername=sc.next();
								result=FhistoryDAO.insertFhistory(site_name, selname);
																								
								if(result!=0)
								{
									int res1 = BuyinfoDAO.deleteBuyinfo(site_name, buyername);
									int res2 = SiteDAO.deleteSite(site_name);
									
									if(res1!=0 && res2!=0)
									{
										System.out.println("Finalized Deal & history record inserted successfully");
									}
								}
								else
								{
									System.out.println("Failed to Finalize deal");
								}
								
								break;
								
													    
							default:
								break;
							}
							
							System.out.println("Press 1 to continue... Any other key to logout");
							cont=sc.nextInt();
							}while(cont == 1);
						  
					  }
					  
					  else if(urole.contains("A") == true) {
						  System.out.println("Under construction");
					  }
					 
					
					
					/*
					 * clist=UserDAO.getCountries(); //countries...
					 * System.out.println("Details of countries are");
					 * System.out.println("-------------------------"); for(Iterator
					 * it=clist.iterator();it.hasNext();) { User c1=(User) it.next();
					 * System.out.println(c1); } //Geting the country details by passing the
					 * countryid List list1=null; sc=new Scanner(System.in);
					 * System.out.println("\nEnter the country id\n"); int cid=sc.nextInt();
					 * System.out.println("Enter the country name"); String cname=sc.next();
					 * System.out.println("");
					 * 
					 * list1=UserDAO.getCountry(cid,cname);
					 * 
					 * if(!(list1.isEmpty())) {
					 * System.out.println("\n\n VALID COUNTRY DETAILS \n\n");
					 * System.out.println("\n\n**** DETAILS OF COUNTRY *** \n\n");
					 * System.out.println("------------------------------------"); for(Iterator
					 * it=list1.iterator();it.hasNext();) System.out.println(it.next()); } else {
					 * System.out.println("Inalid country details"); }
					 */
					
					
				} catch (DBFWException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (DAOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
				
			}
			
			}//switch
			System.out.println("Do you wish to continue(press any number not zero)");
			status=sc.nextInt();
			
			
			
		}
		while(!(status==0)); // 0   
		System.out.println("\n\n Thank You \n\n");
			
	}
}
