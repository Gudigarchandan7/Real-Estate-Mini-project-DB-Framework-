package com.ntt.domain;

public class Mlogin {
	
	private String contactno;
	private String pass;

	public Mlogin(String contactno, String pass) {
		super();
		this.contactno = contactno;
		this.pass = pass;
	}

	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	@Override
	public String toString() {
		return "contactno = " + contactno + ", pass = " + pass.toString();
	}
	
	
}
