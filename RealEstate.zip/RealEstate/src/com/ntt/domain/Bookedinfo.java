package com.ntt.domain;

public class Bookedinfo {
	
	public Bookedinfo(String bname, String sitename, String bookdate, String paystatus, String sname, String loc,
			String prop_type, String amount, String sellertype, String sellername) {
		super();
		this.bname = bname;
		this.sitename = sitename;
		this.bookdate = bookdate;
		this.paystatus = paystatus;
		this.sname = sname;
		this.loc = loc;
		this.prop_type = prop_type;
		this.amount = amount;
		this.sellertype = sellertype;
		this.sellername = sellername;
	}
	private String bname;
	private String sitename;
	private String bookdate;
	private String paystatus;
	private String sname;
	private String loc;
	private String prop_type;
	private String amount;
	private String sellertype;
	private String sellername;
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getSitename() {
		return sitename;
	}
	public void setSitename(String sitename) {
		this.sitename = sitename;
	}
	public String getBookdate() {
		return bookdate;
	}
	public void setBookdate(String bookdate) {
		this.bookdate = bookdate;
	}
	public String getPaystatus() {
		return paystatus;
	}
	public void setPaystatus(String paystatus) {
		this.paystatus = paystatus;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public String getProp_type() {
		return prop_type;
	}
	public void setProp_type(String prop_type) {
		this.prop_type = prop_type;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getSellertype() {
		return sellertype;
	}
	public void setSellertype(String sellertype) {
		this.sellertype = sellertype;
	}
	public String getSellername() {
		return sellername;
	}
	public void setSellername(String sellername) {
		this.sellername = sellername;
	}
	@Override
	public String toString() {
		return "buyer name = " + bname + ", site name = " + sitename + ", bookdate = " + bookdate + ", paystatus = "
				+ paystatus + ", site name = " + sname + ", loc = " + loc + ", prop_type = " + prop_type + ", amount = " + amount
				+ ", sellertype = " + sellertype + ", sellername = " + sellername.toString();
	}
	
	

}
