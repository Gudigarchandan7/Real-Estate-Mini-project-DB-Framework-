package com.ntt.domain;

public class Site {
	
	private String sitename;
	private String loc;
	private String prop_type;
	private String amount;
	private String selltype;
	private String sellername;
	
	public Site(String sitename, String loc, String prop_type, String amount, String selltype, String sellername) {
		super();
		this.sitename = sitename;
		this.loc = loc;
		this.prop_type = prop_type;
		this.amount = amount;
		this.selltype = selltype;
		this.sellername = sellername;
	}

	public String getSitename() {
		return sitename;
	}

	public void setSitename(String sitename) {
		this.sitename = sitename;
	}

	public String getLoc() {
		return loc;
	}

	public void setLoc(String loc) {
		this.loc = loc;
	}

	public String getProp_type() {
		return prop_type;
	}

	public void setProp_type(String prop_type) {
		this.prop_type = prop_type;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getSelltype() {
		return selltype;
	}

	public void setSelltype(String selltype) {
		this.selltype = selltype;
	}

	public String getSellername() {
		return sellername;
	}

	public void setSellername(String sellername) {
		this.sellername = sellername;
	}

	@Override
	public String toString() {
		return "sitename = " + sitename + ", loc = " + loc + ", prop_type = " + prop_type + ", amount = " + amount
				+ ", selltype = " + selltype + ", sellername = " + sellername.toString();
	}
	
	

}
