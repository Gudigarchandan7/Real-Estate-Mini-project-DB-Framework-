package com.ntt.domain;

public class Fhistory {
	
	public Fhistory(String bname, String sname, String site, String loc, String prop_type, String amount,
			String selltype) {
		super();
		this.bname = bname;
		this.sname = sname;
		this.site = site;
		this.loc = loc;
		this.prop_type = prop_type;
		this.amount = amount;
		this.selltype = selltype;
	}
	private String bname;
	private String sname;
	private String site;
	private String loc;
	private String prop_type;
	private String amount;
	private String selltype;
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSite() {
		return site;
	}
	public void setSite(String site) {
		this.site = site;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public String getProp_type() {
		return prop_type;
	}
	public void setProp_type(String prop_type) {
		this.prop_type = prop_type;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getSelltype() {
		return selltype;
	}
	public void setSelltype(String selltype) {
		this.selltype = selltype;
	}
	@Override
	public String toString() {
		
		return "Finalized Deal history [bname=" + bname + ", sname=" + sname + ", site=" + site + ", loc=" + loc + ", prop_type="
				+ prop_type + ", amount=" + amount + ", selltype=" + selltype + "]".toString();
	}
	
	

}
