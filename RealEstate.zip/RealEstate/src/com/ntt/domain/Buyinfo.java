package com.ntt.domain;

public class Buyinfo {
	
	public Buyinfo(String bname, String sitename, String date, String payment) {
		super();
		this.bname = bname;
		this.sitename = sitename;
		Date = date;
		this.payment = payment;
	}
	
	private String bname;
	private String sitename;
	private String Date;
	private String payment;
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getSitename() {
		return sitename;
	}
	public void setSitename(String sitename) {
		this.sitename = sitename;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public String getPayment() {
		return payment;
	}
	public void setPayment(String payment) {
		this.payment = payment;
	}
	@Override
	public String toString() {
		return "bname = " + bname + ", sitename = " + sitename + ", Date = " + Date + ", payment = " + payment.toString();
	}

	
	
}
