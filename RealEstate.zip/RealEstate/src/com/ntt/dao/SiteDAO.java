package com.ntt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.ntt.dbcon.ConnectionHolder;
import com.ntt.dbcon.DBConnectionException;
import com.ntt.dbfw.DBFWException;
import com.ntt.dbfw.DBHelper;
import com.ntt.dbfw.ParamMapper;
import com.ntt.domain.Buyinfo;
import com.ntt.domain.Site;

public class SiteDAO {
	
static Logger log=Logger.getLogger(SiteDAO.class);
	


	public static List getSites() throws DBFWException, DAOException, DBConnectionException
	{
		List sites=null;
		ConnectionHolder ch=null;
		Connection con=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnectionn();
			
			log.debug("fetchig"); // 
			sites = DBHelper.executeSelect(con,SQLMapper.FETCHSITE,SQLMapper.SITEMAPPER);
					
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db ..."+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return sites;
		
	}
	
	public static int insertSite(final Site u)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnectionn();

			final ParamMapper INSERTPSITE=new ParamMapper()
			{
				public void mapParam(PreparedStatement preStmt) throws SQLException 
				{
					preStmt.setString(1, u.getSitename());
					preStmt.setString(2, u.getLoc());
					preStmt.setString(3, u.getProp_type());
					preStmt.setString(4, u.getAmount());
					preStmt.setString(5, u.getSelltype());
					preStmt.setString(6, u.getSellername());
				}
			};
			
			
		//result will trigger execute user defined function defined in Helper functions			
		result=DBHelper.executeUpdate(con,SQLMapper.INSERTSITE,INSERTPSITE);
			 
			
		} 
		
		
		catch (DBFWException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e)
		
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
		
	}//insert
	
	public static int deleteSite(final String sitename)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnectionn();

			final ParamMapper DELETEPSITE=new ParamMapper()
			{
				public void mapParam(PreparedStatement preStmt) throws SQLException 
				{
					preStmt.setString(1, sitename);
				}
			};
			
			
		//result will trigger execute user defined function defined in Helper functions			
		result=DBHelper.executeUpdate(con,SQLMapper.DELETESITE,DELETEPSITE);
			 
			
		} 
		
		
		catch (DBFWException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e)
		
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
		
	}//delete

}
