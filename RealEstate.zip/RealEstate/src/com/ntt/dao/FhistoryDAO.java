package com.ntt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.ntt.dbcon.ConnectionHolder;
import com.ntt.dbcon.DBConnectionException;
import com.ntt.dbfw.DBFWException;
import com.ntt.dbfw.DBHelper;
import com.ntt.dbfw.ParamMapper;
import com.ntt.domain.Site;

public class FhistoryDAO {
	
	static Logger log=Logger.getLogger(FhistoryDAO.class);
	
	public static int insertFhistory(final String site_name, String sellername)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnectionn();

			final ParamMapper INSERTPFHISTORY=new ParamMapper()
			{
				public void mapParam(PreparedStatement preStmt) throws SQLException 
				{
					preStmt.setString(1, site_name);
					preStmt.setString(2, sellername);
				}
			};
			
			
		//result will trigger execute user defined function defined in Helper functions			
		result=DBHelper.executeUpdate(con,SQLMapper.INSERTFHISTORY,INSERTPFHISTORY);
			 
			
		} 
		
		
		catch (DBFWException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e)
		
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
		
	}//insert
	
	
	

}
