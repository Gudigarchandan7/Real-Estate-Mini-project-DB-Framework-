package com.ntt.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.ntt.dbfw.ResultMapper;
import com.ntt.domain.Bookedinfo;
import com.ntt.domain.Buyinfo;
import com.ntt.domain.Site;
import com.ntt.domain.User;

// in oracle or mysql
// create a table named tbl_country 
// create table tbl_country(id numeric(4), name varchar2(30)); in your database ... 

/*
 * then you can import this project to your workspace..
 * add the related libraries... to your project..  
 * execute this project... 
 */



public class SQLMapper
{
	
	public static final String FETCHSITE= "select * from site"; 
	
	public static final String FETCHEROLE= "select urole from user where email = ? AND pass = ?";
	
	public static final String FETCHMROLE= "select urole from user where contact_no = ? AND pass = ?";
	
	public static final String INSERTUSER= "insert into user values(?,?,?,?,?)";
	
	public static final String INSERTBUYINFO= "insert into buy_info values(?,?,?,?)";
	
	public static final String SELECTBUYINFO= "select * from rhistory where bname = ?";
	
	public static final String INSERTSITE = "insert into site values(?,?,?,?,?,?)";
	
	public static final String SELECTBOOKEDINFO = "select * from buy_info as B, site as S where B.site_name = S.sname and S.sellername = ?";
	
	public static final String INSERTFHISTORY = "INSERT INTO rhistory SELECT B.bname, S.sellername, S.sname, S.loc, S.prop_type, S.amount, S.selltype FROM buy_info as B, site as S where B.site_name = S.sname and S.sname = ? and S.sellername = ?"; 
	
	public static final String DELETEBUYINFO = "delete from buy_info where site_name = ? and bname = ?";
	
	public static final String DELETESITE = "delete from site where sname = ?";
	
	
	public static final ResultMapper USERMAPPER = new ResultMapper()
	{
		
		
		public Object mapRow(ResultSet rs) throws SQLException
        {
			
		String name=rs.getString(1);
		String email=rs.getString(2);
		String pass=rs.getString(2);
		String contactno=rs.getString(2);
		String role=rs.getString(2);
		
		User u=new User(name, email, pass, contactno, role);  // Country c = new Country(id, name, pop)
		
		
			return u;
		}
		//mapRow 
	};
		
		
		
	public static final ResultMapper ROLEMAPPER = new ResultMapper()
	{
			
			
		public Object mapRow(ResultSet rs) throws SQLException
	    {
				
			String urole=rs.getString(1);			
			
			return urole;
		}
	};
		
	//Anonymous class
	
	
	public static final ResultMapper SITEMAPPER = new ResultMapper()
	{
		
		
		public Object mapRow(ResultSet rs) throws SQLException
        {
			
		String sitename=rs.getString(1);
		String loc=rs.getString(2);
		String prop_type=rs.getString(3);
		String amount=rs.getString(4);
		String selltype=rs.getString(5);
		String sellername=rs.getString(6);
		
		Site u=new Site(sitename, loc, prop_type, amount, selltype, sellername);  // Country c = new Country(id, name, pop)
		
		
		return u;
		}
		//mapRow 
	};
	
	public static final ResultMapper BUYINFOMAPPER = new ResultMapper()
	{
		
		
		public Object mapRow(ResultSet rs) throws SQLException
        {
			
		String bname=rs.getString(1);
		String sitename=rs.getString(2);
		String date=rs.getString(3);
		String payment=rs.getString(4);
		
		Buyinfo u=new Buyinfo(bname, sitename, date, payment);  // 
		
		
		return u;
		}
		//mapRow 
	};
	
	
	public static final ResultMapper BOOKEDINFOMAPPER = new ResultMapper()
	{
		
		
		public Object mapRow(ResultSet rs) throws SQLException
        {
			
		String bname=rs.getString(1);
		String site_name=rs.getString(2);
		String booked_date=rs.getString(3);
		String pay_status=rs.getString(4);
		String sname=rs.getString(5);
		String loc=rs.getString(6);
		String prop_type=rs.getString(7);
		String amount=rs.getString(8);
		String selltype=rs.getString(9);
		String sellername=rs.getString(10);
		
		Bookedinfo u=new Bookedinfo(bname, site_name, booked_date, pay_status,sname, loc, prop_type, amount, selltype, sellername);  // Country c = new Country(id, name, pop)
		
		
		return u;
		}
		//mapRow 
	};
	 
	
}


// Student 3 id, name , address

// id , name  






