package com.ntt.dao;




import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.ntt.dbcon.ConnectionHolder;
import com.ntt.dbcon.DBConnectionException;
import com.ntt.dbfw.DBFWException;
import com.ntt.dbfw.DBHelper;
import com.ntt.dbfw.ParamMapper;
import com.ntt.domain.User;

public class UserDAO
{
	
	
static Logger log=Logger.getLogger(UserDAO.class);
	

/*
 * public static List getCountries() throws DBFWException, DAOException,
 * DBConnectionException { List countries=null; ConnectionHolder ch=null;
 * Connection con=null; try { ch=ConnectionHolder.getInstance();
 * con=ch.getConnectionn();
 * 
 * log.debug("fetchig"); //
 * countries=DBHelper.executeSelect(con,SQLMapper.FETCHEROLE,SQLMapper.
 * USERMAPPER);
 * 
 * } catch (DBConnectionException e) { throw new
 * DBConnectionException("Unable to connect to db "+e);
 * 
 * } finally {
 * 
 * try {
 * 
 * if (con != null) con.close();
 * 
 * } catch (SQLException e) { } }
 * 
 * 
 * return countries;
 * 
 * }//getcountry
 * 
 * 
 * public static List getCountry(final int cid,final String cname) {
 * ConnectionHolder ch=null; Connection con=null; List country=null;
 * 
 * try { ch=ConnectionHolder.getInstance(); con=ch.getConnectionn(); final
 * ParamMapper COUNTRYPMAPPER=new ParamMapper() // select id, name from user
 * where id=? password=? {
 * 
 * public void mapParam(PreparedStatement preStmt) throws SQLException {
 * preStmt.setInt(1,cid); preStmt.setString(2,cname); }
 * 
 * };//ananymous class
 * 
 * //country=DBHelper.executeSelect
 * //(con,SQLMapper.FETCHCOUNTRYID,SQLMapper.USERMAPPER, COUNTRYPMAPPER );
 * 
 * } catch (DBConnectionException e) { // TODO Auto-generated catch block
 * e.printStackTrace(); } return country;
 * 
 * }//getcountry
 */
	
	
	//insert User 
	public static int insertUser(final User u)// stid stname,stpopulation
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnectionn();

			final ParamMapper INSERTPUSER=new ParamMapper()
			{
				public void mapParam(PreparedStatement preStmt) throws SQLException 
				{
					preStmt.setString(1, u.getName());
					preStmt.setString(2, u.getEmail());
					preStmt.setString(3, u.getPass());
					preStmt.setString(4, u.getContactno());
					preStmt.setString(5, u.getRole());					
				}
			};
			
			
		//result will trigger execute user defined function defined in Helper functions			
		result=DBHelper.executeUpdate(con,SQLMapper.INSERTUSER,INSERTPUSER);
			 
			
		} 
		
		
		catch (DBFWException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e)
		
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
		
	}//insert
	
	
	
}
