package com.ntt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.ntt.dbcon.ConnectionHolder;
import com.ntt.dbcon.DBConnectionException;
import com.ntt.dbfw.DBHelper;
import com.ntt.dbfw.ParamMapper;

public class BookedinfoDAO {
	
	static Logger log=Logger.getLogger(BookedinfoDAO.class);
	
	public static List getBookedinfo(final String sname)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		List bookedinfo=null;
		
		try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnectionn();
				
			final ParamMapper BOOKEDINFOPMAPPER=new ParamMapper()  // select id, name  from user where id=? password=? 
			{

				public void mapParam(PreparedStatement preStmt) throws SQLException {
				preStmt.setString(1,sname);						
				}
				
			};//ananymous class
			
			bookedinfo = DBHelper.executeSelect(con,SQLMapper.SELECTBOOKEDINFO,SQLMapper.BOOKEDINFOMAPPER, BOOKEDINFOPMAPPER );		
	
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bookedinfo;
		
	}//get buy info

}
