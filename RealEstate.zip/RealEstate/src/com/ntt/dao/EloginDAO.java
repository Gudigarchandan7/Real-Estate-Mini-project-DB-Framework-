package com.ntt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.ntt.dbcon.ConnectionHolder;
import com.ntt.dbcon.DBConnectionException;
import com.ntt.dbfw.DBFWException;
import com.ntt.dbfw.DBHelper;
import com.ntt.dbfw.ParamMapper;
import com.ntt.domain.Elogin;

public class EloginDAO {
	
	static Logger log=Logger.getLogger(EloginDAO.class);
	
	public static List eloginSelect(Elogin e1) throws DBFWException, DAOException, DBConnectionException
	{
		List role=null;
		ConnectionHolder ch=null;
		Connection con=null;
		//System.out.println("---------------check 1---------------");
		try {
			ch=ConnectionHolder.getInstance();
			//System.out.println("---------------check 1---------------");
			con=ch.getConnectionn();
			//System.out.println("---------------check 2---------------");
			
			final ParamMapper FETCHROLE=new ParamMapper()
			{
				public void mapParam(PreparedStatement preStmt) throws SQLException 
				{
					preStmt.setString(1, e1.getEmail());
					preStmt.setString(2, e1.getPass());			
				}
			};
			
			log.debug("fetchig");
			role = DBHelper.executeSelect(con,SQLMapper.FETCHEROLE, SQLMapper.ROLEMAPPER, FETCHROLE);
			//System.out.println("---------------check 3---------------");		
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db... "+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return role;
		
	}//getcountry

}
