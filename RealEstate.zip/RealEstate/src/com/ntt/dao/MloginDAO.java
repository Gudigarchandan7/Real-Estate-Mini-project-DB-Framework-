package com.ntt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.ntt.dbcon.ConnectionHolder;
import com.ntt.dbcon.DBConnectionException;
import com.ntt.dbfw.DBFWException;
import com.ntt.dbfw.DBHelper;
import com.ntt.dbfw.ParamMapper; 
import com.ntt.domain.Mlogin;

public class MloginDAO {
	
static Logger log=Logger.getLogger(MloginDAO.class);
	
	public static List mloginSelect(Mlogin m1) throws DBFWException, DAOException, DBConnectionException
	{
		List role=null;
		ConnectionHolder ch=null;
		Connection con=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnectionn();
			
			final ParamMapper FETCHROLE=new ParamMapper()
			{
				public void mapParam(PreparedStatement preStmt) throws SQLException 
				{
					preStmt.setString(1, m1.getContactno());
					preStmt.setString(2, m1.getPass());			
				}
			};
			
			log.debug("fetchig"); // 
			role = DBHelper.executeSelect(con, SQLMapper.FETCHMROLE, SQLMapper.ROLEMAPPER, FETCHROLE);
					
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return role;
		
	}


}
