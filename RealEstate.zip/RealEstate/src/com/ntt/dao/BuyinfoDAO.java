package com.ntt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.ntt.dbcon.ConnectionHolder;
import com.ntt.dbcon.DBConnectionException;
import com.ntt.dbfw.DBFWException;
import com.ntt.dbfw.DBHelper;
import com.ntt.dbfw.ParamMapper;
import com.ntt.domain.Buyinfo;

public class BuyinfoDAO {
	
	static Logger log=Logger.getLogger(BuyinfoDAO.class);
	
	public static int insertBuyinfo(final Buyinfo u)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnectionn();

			final ParamMapper INSERTPBUYINFO=new ParamMapper()
			{
				public void mapParam(PreparedStatement preStmt) throws SQLException 
				{
					preStmt.setString(1, u.getBname());
					preStmt.setString(2, u.getSitename());
					preStmt.setString(3, u.getDate());
					preStmt.setString(4, u.getPayment());
				}
			};
			
			
		//result will trigger execute user defined function defined in Helper functions			
		result=DBHelper.executeUpdate(con,SQLMapper.INSERTBUYINFO,INSERTPBUYINFO);
			 
			
		} 
		
		
		catch (DBFWException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e)
		
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
		
	}//insert

	
	
	public static List getBuyinfo(final String bname)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		List buyinfo=null;
		
		try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnectionn();
			final ParamMapper BUYINFOPMAPPER=new ParamMapper()  // select id, name  from user where id=? password=? 
			{

				public void mapParam(PreparedStatement preStmt) throws SQLException {
				preStmt.setString(1,bname);						
				}
				
			};//ananymous class
			
		buyinfo = DBHelper.executeSelect(con,SQLMapper.SELECTBUYINFO,SQLMapper.BUYINFOMAPPER, BUYINFOPMAPPER );		
	
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return buyinfo;
		
	}//get buy info
	
	
	
	
	
	
	public static int deleteBuyinfo(final String sitename,final String buyername)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnectionn();

			final ParamMapper DELETEPBUYINFO=new ParamMapper()
			{
				public void mapParam(PreparedStatement preStmt) throws SQLException 
				{
					preStmt.setString(1, sitename);
					preStmt.setString(2, buyername);
				}
			};
			
			
		//result will trigger execute user defined function defined in Helper functions			
		result=DBHelper.executeUpdate(con,SQLMapper.DELETEBUYINFO,DELETEPBUYINFO);
			 
			
		} 
		
		
		catch (DBFWException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e)
		
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
		
	}//delete
}
